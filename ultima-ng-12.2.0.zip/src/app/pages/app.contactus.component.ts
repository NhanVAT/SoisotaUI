import {Component} from '@angular/core';

@Component({
    selector: 'app-contactus',
    templateUrl: './app.contactus.component.html',
})
export class AppContactusComponent{

}
